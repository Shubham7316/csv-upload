# csv-webapp
here is link to my hosted webapp where you can try my webapp
website: https://csv-webapp.onrender.com/
this is a simple csv file uploader where you can upload and view your csv files
github: https://github.com/yuvraj00001/csv-webapp
to get this webapp in your localdevice copy my repository and get dependencies in your local device and start the server. 
